package SWTeam2.vocabulary.SWTeam2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SwTeam2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
