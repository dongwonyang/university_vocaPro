package SWTeam2.vocabulary.SWTeam2.auth;

import lombok.Getter;

@Getter
public enum Authority {
    ROLE_USER, ROLE_ADMIN
}

