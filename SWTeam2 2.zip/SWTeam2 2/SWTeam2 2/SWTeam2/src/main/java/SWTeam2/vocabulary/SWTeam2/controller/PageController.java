package SWTeam2.vocabulary.SWTeam2.controller;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;


//로그인
@Controller
public class PageController { //다른 컨트롤러랑 이름 겹치면 안됨
    @GetMapping("loginPage")
    public String loginPage(Model model){
        return "loginPage";
    }
    @GetMapping("home")
    public String mainPate(Model model){
        return "home";
    }
    @GetMapping("levelTest")
    public String levelTest(Model model){
        return "levelTest";
    }
    @GetMapping("pwFind")
    public String PasswordFindPage(Model model){
        return "pwFind";
    }
    @GetMapping("joinMem")
    public String JoinMemPage(Model model){
        return "joinMem";
    }
    @GetMapping("groupTier")
    public String GroupTier(Model model){
        return "groupTier";
    }
    @GetMapping("groupWrong")
    public String groupWrong(Model model){
        return "groupWrong";
    }
    @GetMapping("testGiveUp")
    public String testGiveUp(Model model){
        return "testGiveUp";
    }
    @GetMapping("groupMyAdded")
    public String groupMyAdded(Model model){
        return "groupMyAdded";
    }
    @GetMapping("IndexAdd")
    public String IndexAdd(Model model){
        return "IndexAdd";
    }
    @GetMapping("IndexAll")
    public String IndexAll(Model model){
        return "IndexAll";
    }
    @GetMapping("IndexModify")
    public String IndexModify(Model model){
        return "IndexModify";
    }
    @GetMapping("levelTestButton")
    public String levelTestButton(Model model){
        return "levelTestButton";
    }
    @GetMapping("levelTestResult2")
    public String levelTestResult2(Model model){
        return "levelTestResult2";
    }
    @GetMapping("IndexModifyFailed")
    public String IndexModifyFailed(Model model){
        return "IndexModifyFailed";
    }
    @GetMapping("IndexTestResult2")
    public String IndexTestResult2(Model model){
        return "IndexTestResult2";
    }
    @GetMapping("myPage")
    public String myPage(Model model){
        return "myPage";
    }
    @GetMapping("testSelec")
    public String testSelec(Model model){ return "testSelec"; }
    @GetMapping("testWords_15")
    public String testWords_15(Model model){ return "testWords_15"; }
    @GetMapping("testWords_20")
    public String testWords_20(Model model){ return "testWords_20"; }
    @GetMapping("testWords_25")
    public String testWords_25(Model model){ return "testWords_25"; }
    @GetMapping("indexAll_manage")
    public String indexAll_manage(Model model){ return "indexAll_manage"; }
    @GetMapping("indexAll")
    public String indexAll(Model model){ return "indexAll"; }
    @GetMapping("studyWords_15")
    public String studyWords_15(Model model){ return "studyWords_15"; }
    @GetMapping("studyWords_20")
    public String studyWords_20(Model model){ return "studyWords_20"; }
    @GetMapping("studyWords_25")
    public String studyWords_25(Model model){ return "studyWords_25"; }


}
