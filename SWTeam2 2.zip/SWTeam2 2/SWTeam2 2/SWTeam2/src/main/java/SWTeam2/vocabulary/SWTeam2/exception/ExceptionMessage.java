package SWTeam2.vocabulary.SWTeam2.exception;

public class ExceptionMessage extends RuntimeException{
    public ExceptionMessage(String message){
        super(message);
    }
}
