//package SWTeam2.vocabulary.SWTeam2.Util;
//
//public List<VocaDto> Util(int maxcnt){
//
//
//}
